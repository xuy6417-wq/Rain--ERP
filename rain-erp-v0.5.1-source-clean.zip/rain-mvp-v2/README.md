# Rain ERP v0.5 — 采购、入库与库存流水

基于此前 v0.4 项目增量升级，保留原有商品 SPU/SKU、供应商、1688 报价、仓库、库存、利润测算和订单接口/页面。v0.5 新增采购单、采购提交、部分/全部收货、库存变动流水。

## 技术栈
- Web: Next.js 14 App Router / React 18 / TypeScript
- API: FastAPI / SQLAlchemy 2 / Pydantic 2
- DB: PostgreSQL 16（本地开发可用 Docker）
- Redis 7（基础设施预留，当前采购流程未依赖 Redis）

## 一键启动（Docker）
在项目根目录执行：

```bash
docker compose up --build -d
```

访问：
- ERP 前端：http://localhost:3000
- 采购/入库工作台：http://localhost:3000/procurement
- API 文档：http://localhost:8000/docs
- 健康检查：http://localhost:8000/health

停止：`docker compose down`。保留数据库数据；如需连数据一起清空，使用 `docker compose down -v`（会删除本地数据库卷）。

## 本地开发（不使用 Docker 跑应用）
先启动 PostgreSQL/Redis：`docker compose up -d postgres redis`

API：
```bash
cd apps/api
python -m venv .venv
# macOS/Linux: source .venv/bin/activate
# Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
# DATABASE_URL 默认指向本机 rain 数据库
uvicorn app.main:app --reload --port 8000
```

Web（新终端）：
```bash
cd apps/web
npm install
# macOS/Linux
NEXT_PUBLIC_API_URL=http://localhost:8000 npm run dev
# Windows PowerShell: $env:NEXT_PUBLIC_API_URL='http://localhost:8000'; npm run dev
```

## v0.5 新增 API

| 方法 | 路径 | 用途 |
|---|---|---|
| POST | `/api/v1/purchase-orders` | 创建采购单草稿（支持多 SKU） |
| GET | `/api/v1/purchase-orders` | 采购单列表，可用 `?status=ordered` 过滤 |
| GET | `/api/v1/purchase-orders/{id}` | 采购单详情 |
| POST | `/api/v1/purchase-orders/{id}/submit` | 提交采购单 |
| POST | `/api/v1/purchase-orders/{id}/cancel` | 取消草稿/已提交采购单 |
| POST | `/api/v1/goods-receipts` | 按采购单行收货，可部分入库/分批入库 |
| GET | `/api/v1/goods-receipts` | 收货单列表 |
| GET | `/api/v1/inventory/movements` | 库存流水，支持仓库/SKU过滤 |
| POST | `/api/v1/inventory/adjustments` | 人工库存调整并记流水 |

## 关键业务规则
1. 采购单必须关联有效供应商、仓库和 SKU；同一采购单 SKU 不重复。
2. 采购单先处于 `draft`，提交后为 `ordered`；仅 `ordered` / `partially_received` 可以收货。
3. 收货数量不能超过采购单剩余未收数量；收货、采购行累计收货量、库存增加和库存流水在同一数据库事务中提交。
4. 全部收齐后状态变为 `received`，部分收货为 `partially_received`。
5. 每笔库存流水记录变动前数量、变动数量、变动后数量、仓库、SKU、来源单据和时间。流水为追加记录，不提供修改/删除接口。
6. 人工调整不得使在库数量低于已锁定数量。

## 数据库升级说明
API 启动时通过 SQLAlchemy `create_all` 创建缺失表，不会删除 v0.4 的业务表。新表：`purchase_orders`、`purchase_order_lines`、`goods_receipts`、`inventory_movements`。正式生产环境下一步应迁移到 Alembic 管理版本化迁移，并补充登录/RBAC、审计和幂等键。

## 重要说明
- 采购工作台在 `/procurement`；首页侧边栏有入口。
- 采购工作台支持一张采购单添加多个 SKU，并可编辑预计到货日期、采购备注和各行采购数量/单价。
- 收货时可按采购单行填写本次入库数量，支持部分入库和多次收货；前端会预先校验数量，后端仍会再次校验超量入库。
- 工作台提供采购单状态筛选、收货记录列表、库存流水仓库/SKU筛选，以及采购单/待收货/待入库件数概览。
- 此包是可运行的 v0.5 开发版本，不代表已经部署到 Railway production。上线前需配置 Railway PostgreSQL、API/Web 服务环境变量、域名和 CORS/鉴权策略。


## v0.5.1 前端增强与验证
- 采购工作台已升级为响应式 ERP 布局，包含多 SKU 采购录入、采购状态操作、部分入库、收货记录和库存流水筛选。
- API 集成验证已通过：创建采购单、提交采购单、部分入库、库存流水前后数量核对、超量入库拦截。
- 前端 TSX 语法转译检查通过。当前构建容器无法连接 npm registry，依赖安装超时，因此尚未在本环境完成 `next build`；在可访问 npm registry 的机器执行 `cd apps/web && npm install && npm run build` 完成最终生产构建验证。
